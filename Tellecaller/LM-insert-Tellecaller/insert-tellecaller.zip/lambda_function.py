import json
import boto3
from datetime import datetime, date
import logging
import pymysql
from DB_manager import DatabaseManager

s3 = boto3.client('s3')

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    print(event)
    print(event['body'])
    data = json.loads(event['body'])

    insert_tellecaller = """
        INSERT INTO LMS.Tellecaller (
            Name,
            Email_Id,
            Password,
            Gender,
            Mobile_Number,
            Employee_Id,
            Designation,
            Partner_Id,
            Status,
            Profile_Status
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    conn = DatabaseManager.get_db_connection()
    with conn.cursor() as cur:
        cur.execute(insert_tellecaller, (
            data['Name'],
            data['Email_Id'],
            data['Password'],
            data['Gender'],
            data['Mobile_Number'],
            data['Employee_Id'],
            data['Designation'],
            data['Partner_Id'],
            data['Status'],
            data['Profile_Status']
        ))
        print("Tellecaller Inserted Successfully")
        conn.commit()

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "statusCode": 200,
            "responseMessage": "Tellecaller DETAILS INSERTED SUCCESSFULLY",
            "response": "Tellecaller DETAILS INSERTED SUCCESSFULLY"
        })
    }

if __name__ == "__main__":
    events = {
        "body": json.dumps({
            'Name': 'John Doe',
            'Email_Id': 'john.doe@example.com',
            'Password': 'securepassword',
            'Gender': 1,
            'Mobile_Number': '1234567890',
            'Employee_Id': 'EMP123',
            'Designation': 'Manager',
            'Partner_Id': 3,
            'Status': 1,
            'Profile_Status': 2
        })
    }
    lambda_handler(event=events, context="")
