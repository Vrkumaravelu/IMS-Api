import json
import boto3
from datetime import datetime, timedelta, date
from DB_manager import DatabaseManager
import jwt
import logging
import pymysql
from bson import json_util
import secret_manager
from botocore.exceptions import ClientError
import hashlib

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def encrypt_password(password):
    # Convert the password to bytes
    password_bytes = password.encode('utf-8')

    # Choose the hash function (e.g., hashlib.sha256())
    hash_function = hashlib.sha256()

    # Update the hash object with the password bytes
    hash_function.update(password_bytes)

    # Get the hexadecimal representation of the digest
    hashed_password = hash_function.hexdigest()

    return hashed_password

def generate_jwt_token(request_id, mobile_number, jwt_secret):
    issued_at = datetime.utcnow()
    expiration_time = issued_at + timedelta(minutes=30)  # Token expires after 30 minutes
    payload = {
        'sub': mobile_number,  # 'sub' claim for the principal subject
        'request_id': request_id,  # Additional custom claim
        'iat': issued_at.timestamp(),  # Issued at time
        'exp': expiration_time.timestamp()  # Expiration time
    }
    jwt_token = jwt.encode(payload, jwt_secret, algorithm='HS256')
    return jwt_token

def get_jwt_secret():
    secret_name =secret_manager.JWT_SECRET_KEY
    #client = boto3.client('secretsmanager')
    try:
        #get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        return secret_name
    except ClientError as e:
        print(f"Error retrieving secret: {e}")
        raise e

def lambda_handler(event, context):
    data = json.loads(event['body'])
    username = data["username"]
    passwrd = encrypt_password(data["password"])
    user_role= data["user_role"]

    try:
        conn = DatabaseManager.get_db_connection()
        if user_role =="dealer":
            sql_query="select * from LMS.User Where Email_Id={} and Password={}".format(username,passwrd)
        else:
            sql_query="select * from LMS.Tellecaller Where Email_Id={} and Password={}".format(username,passwrd)
        with conn.cursor() as cur:
            cur.execute(sql_query)
            rv = cur.fetchall()
            row_headers = [x[0] for x in cur.description]
            json_data=[]

            if not rv:
                return {
                    "statusCode": 404,
                    "headers": {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Headers": "Content-Type",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
                    },
                    "body": json.dumps("User Not Found In Database", default=json_util.default)  # <-- There is an undefined "json_util" here
                }
            else:
                json_data = []
                for result in rv:
                    json_data.append(dict(zip(row_headers, result)))
                
                jwt_secret = get_jwt_secret()
                jwt_token = generate_jwt_token(request_id=username, mobile_number=json_data[4], jwt_secret=jwt_secret)
                json_data.append({"token":jwt_token})
                return {
                    "statusCode": 200,
                    "headers": {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Headers": "Content-Type",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
                    },
                    "body": json.dumps(json_data, cls=CustomJSONEncoder)  # Use the CustomJSONEncoder to handle datetime objects
                }
    except pymysql.Error as e:
        print(e)
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
            },

            "body": json.dumps("invalid username and password", cls=CustomJSONEncoder)  # Use the CustomJSONEncoder to handle datetime objects
        }

        

