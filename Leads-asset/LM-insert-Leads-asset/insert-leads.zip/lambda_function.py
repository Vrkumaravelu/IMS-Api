import json
import boto3
from datetime import datetime, timedelta, date
from DB_manager import DatabaseManager
import logging
import pymysql
import pybase64
import uuid
import random
import string
import hashlib

#json parser for parsing json
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#using boto connection to s3 buckets
s3 = boto3.client('s3')

def lambda_handler(event, context):
    
    try:
        conn = DatabaseManager.get_db_connection()
        data = json.loads(event['body'])  
        
        imgdata = pybase64.b64decode(data['Id_Proof_Image'])
        requestid=uuid.uuid4()
        filename = 'assets/partner/id_proof/{}.jpg'.format(requestid)
       
        s3.put_object(Bucket='leads-management-system', Key=filename, Body=imgdata)
        partner_data = [data['asset_name'],filename,data['asset_status'],data['Lead_detail_id']]
        print(partner_data)
        sql_partner_data_ins = '''INSERT INTO LMS.Leads_asset (asset_name,asset_path,asset_status,Lead_detail_id) values (%s,%s,%s,%s)'''
        with conn.cursor() as cur:
            cur.execute(sql_partner_data_ins, partner_data)
            division_data_id = conn.insert_id()
            print("id: ", division_data_id)
            conn.commit()
            
            return {
                "statusCode": 200,
                "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                "body": json.dumps({"status": "success", "division_id":division_data_id})
            }
    except pymysql.Error as e:
        print(e)
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
            },

            "body": json.dumps("Database Connection Issue", cls=CustomJSONEncoder)  # Use the CustomJSONEncoder to handle datetime objects
        }

        

