import json
import boto3
from datetime import datetime, date
import logging
import pymysql
from DB_manager import DatabaseManager

s3 = boto3.client('s3')

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    print(event)
    print(event['body'])
    data = json.loads(event['body'])

    update_leads_details = """
        UPDATE LMS.Lead_Details
        SET
            First_Name=%s,
            Last_Name=%s,
            Mobile_No=%s,
            Company_Name=%s,
            Company_Type_Id=%s,
            Salary=%s,
            Loan_Amount=%s,
            Bank_Id=%s,
            Loan_Type_Id=%s,
            Loan_Process_Status_Id=%s,
            Payslip_Image_Path=%s,
            Generated_Partner=%s,
            Generated_By=%s,
            Lead_Status=%s,
            Generated_On=%s
        WHERE Lead_Details_Id=%s
    """

    conn = DatabaseManager.get_db_connection()
    with conn.cursor() as cur:
        cur.execute(update_leads_details, (
            data['First_Name'],
            data['Last_Name'],
            data['Mobile_No'],
            data['Company_Name'],
            data['Company_Type_Id'],
            data['Salary'],
            data['Loan_Amount'],
            data['Bank_Id'],
            data['Loan_Type_Id'],
            data['Loan_Process_Status_Id'],
            data['Payslip_Image_Path'],
            data['Generated_Partner'],
            data['Generated_By'],
            data['Lead_Status'],
            data['Generated_On'],
            data['Lead_Details_Id']
        ))
        print("Executed Successfully")
        conn.commit()

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "statusCode": 200,
            "responseMessage": "LEAD DETAILS UPDATED SUCCESSFULLY",
            "response": "LEAD DETAILS UPDATED SUCCESSFULLY"
        })
    }

if __name__ == "__main__":
    events = {
        "body": json.dumps({
            'First_Name': 'siva',
            'Last_Name': 'Doe',
            'Mobile_No': '1234567890',
            'Company_Name': 'ABC Corp',
            'Company_Type_Id': '1',
            'Salary': 50000,
            'Loan_Amount': 100000,
            'Bank_Id': 12345,
            'Loan_Type_Id': 1,
            'Loan_Process_Status_Id': 2,
            'Payslip_Image_Path': '/path/to/image.png',
            'Generated_Partner': 'Partner1',
            'Generated_By': 'User123',
            'Lead_Status': 'Active',
            'Generated_On': '2023-01-01T12:00:00Z',
            'Lead_Details_Id': '2'
        })
    }
    lambda_handler(event=events, context="")
